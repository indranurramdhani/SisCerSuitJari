AUTHOR: Indra Ismail Nurramdhani

LICENSE: CC-BY-SA 4.0

DESCRIPTION: This dataset contains images of hand gestures from the littlefinger, indexfinger and thumb